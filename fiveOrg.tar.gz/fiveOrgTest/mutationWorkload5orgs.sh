jmeterpath=/Users/j.guo/Downloads/apache-jmeter-3.0/bin
items_per_req=10
throughput_per_min_merge=30
throughput_per_min_convert=30
saveFieldsPath=/Users/j.guo/EAP-Perf-Scripts/datasetup/Mutations/

input_file_convert_1=00Dx0000000H2ldEAC_convert
input_file_merge_1=00Dx0000000H2ldEAC_merge

input_file_convert_2=00Dx0000000H2leEAC_convert 
input_file_merge_2=00Dx0000000H2leEAC_merge   

input_file_convert_1=00Dx0000000H2msEAC_convert  
input_file_merge_1=00Dx0000000H2msEAC_merge 

input_file_convert_1=00Dx0000000H2mtEAC_convert   
input_file_merge_1=00Dx0000000H2mtEAC_merge  

input_file_convert_1=00Dx0000000H2mxEAC_convert 
input_file_merge_1=00Dx0000000H2mxEAC_merge   

java -Xms512M -Xmx1G -jar $jmeterpath/ApacheJMeter.jar -n -t singleOrgMutateMerge.jmx -Jthreads=20 -Jthroughput_per_min_merge=$throughput_per_min_merge -Jinput_file=$input_file_convert_1 -Jsave_file=$input_file_convert_1 -Jitems_per_req=$items_per_req -JsaveFieldsPath=$saveFieldsPath &
java -Xms512M -Xmx1G -jar $jmeterpath/ApacheJMeter.jar -n -t singleOrgMutateConvert.jmx -Jthreads=20 -Jthroughput_per_min_convert=$throughput_per_min_convert -Jinput_file=$input_file_merge_1 -Jsave_file=$input_file_merge_1 -Jitems_per_req=$items_per_req -JsaveFieldsPath=$saveFieldsPath &
java -Xms512M -Xmx1G -jar $jmeterpath/ApacheJMeter.jar -n -t singleOrgMutateMerge.jmx -Jthreads=20 -Jthroughput_per_min_merge=$throughput_per_min_merge -Jinput_file=$input_file_convert_2 -Jsave_file=$input_file_convert_2 -Jitems_per_req=$items_per_req -JsaveFieldsPath=$saveFieldsPath &
java -Xms512M -Xmx1G -jar $jmeterpath/ApacheJMeter.jar -n -t singleOrgMutateConvert.jmx -Jthreads=20 -Jthroughput_per_min_convert=$throughput_per_min_convert -Jinput_file=$input_file_merge_2 -Jsave_file=$input_file_merge_2 -Jitems_per_req=$items_per_req -JsaveFieldsPath=$saveFieldsPath &
java -Xms512M -Xmx1G -jar $jmeterpath/ApacheJMeter.jar -n -t singleOrgMutateMerge.jmx -Jthreads=20 -Jthroughput_per_min_merge=$throughput_per_min_merge -Jinput_file=$input_file_convert_3 -Jsave_file=$input_file_convert_3 -Jitems_per_req=$items_per_req -JsaveFieldsPath=$saveFieldsPath &
java -Xms512M -Xmx1G -jar $jmeterpath/ApacheJMeter.jar -n -t singleOrgMutateConvert.jmx -Jthreads=20 -Jthroughput_per_min_convert=$throughput_per_min_convert -Jinput_file=$input_file_merge_3 -Jsave_file=$input_file_merge_3 -Jitems_per_req=$items_per_req -JsaveFieldsPath=$saveFieldsPath &
java -Xms512M -Xmx1G -jar $jmeterpath/ApacheJMeter.jar -n -t singleOrgMutateMerge.jmx -Jthreads=20 -Jthroughput_per_min_merge=$throughput_per_min_merge -Jinput_file=$input_file_convert_4 -Jsave_file=$input_file_convert_4 -Jitems_per_req=$items_per_req -JsaveFieldsPath=$saveFieldsPath &
java -Xms512M -Xmx1G -jar $jmeterpath/ApacheJMeter.jar -n -t singleOrgMutateConvert.jmx -Jthreads=20 -Jthroughput_per_min_convert=$throughput_per_min_convert -Jinput_file=$input_file_merge_4 -Jsave_file=$input_file_merge_4 -Jitems_per_req=$items_per_req -JsaveFieldsPath=$saveFieldsPath &
java -Xms512M -Xmx1G -jar $jmeterpath/ApacheJMeter.jar -n -t singleOrgMutateMerge.jmx -Jthreads=20 -Jthroughput_per_min_merge=$throughput_per_min_merge -Jinput_file=$input_file_convert_5 -Jsave_file=$input_file_convert_5 -Jitems_per_req=$items_per_req -JsaveFieldsPath=$saveFieldsPath &
java -Xms512M -Xmx1G -jar $jmeterpath/ApacheJMeter.jar -n -t singleOrgMutateConvert.jmx -Jthreads=20 -Jthroughput_per_min_convert=$throughput_per_min_convert -Jinput_file=$input_file_merge_5 -Jsave_file=$input_file_merge_5 -Jitems_per_req=$items_per_req -JsaveFieldsPath=$saveFieldsPath &