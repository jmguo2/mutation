jmeterpath=/Users/j.guo/Downloads/apache-jmeter-3.0/bin
input_file_merge_s=/Users/j.guo/EAP-Perf-Scripts/datasetup/Mutations/allorgsmerge_s.csv  
input_file_convert_s=/Users/j.guo/EAP-Perf-Scripts/datasetup/Mutations/allorgsconvert_s.csv

input_file_merge_m=/Users/j.guo/EAP-Perf-Scripts/datasetup/Mutations/allorgsmerge_m.csv  
input_file_convert_m=/Users/j.guo/EAP-Perf-Scripts/datasetup/Mutations/allorgsconvert_m.csv

input_file_merge_l=/Users/j.guo/EAP-Perf-Scripts/datasetup/Mutations/allorgsmerge_l.csv  
input_file_convert_l=/Users/j.guo/EAP-Perf-Scripts/datasetup/Mutations/allorgsconvert_l.csv
threads_s=125
threads_m=200
threads_l=150
threads_xl=200
threads_xxl=200
java -Xms1G -Xmx2G -jar $jmeterpath/ApacheJMeter.jar -n -t ingestion.jmx -Jthreads=$threads_s -Jthroughput_per_min=50000 -Jinput_file_convert=$input_file_convert_s -Jinput_file_merge=$input_file_merge_s & 
java -Xms1G -Xmx2G -jar $jmeterpath/ApacheJMeter.jar -n -t ingestion.jmx -Jthreads=$threads_m -Jthroughput_per_min=50000 -Jinput_file_convert=$input_file_convert_m -Jinput_file_merge=$input_file_merge_m &
java -Xms1G -Xmx2G -jar $jmeterpath/ApacheJMeter.jar -n -t ingestion.jmx -Jthreads=$threads_l -Jthroughput_per_min=50000 -Jinput_file_convert=$input_file_convert_l -Jinput_file_merge=$input_file_merge_l 

